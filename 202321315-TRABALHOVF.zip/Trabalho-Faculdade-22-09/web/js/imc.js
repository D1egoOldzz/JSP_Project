
function calcularIMC()
{
    const inputIdade = document.getElementById("idadeinput");
    let result = document.getElementById("presult");
    let imc = 0;
    let peso = parseFloat(document.getElementById('pesoinput').value);
    let altura = parseFloat(document.getElementById('alturainput').value);

    imc = peso / (altura * altura);    
    result.style.display = "block";
    result.innerHTML = 'Seu IMC &Eacute; de ' + imc;
    console.log(imc);

    
}