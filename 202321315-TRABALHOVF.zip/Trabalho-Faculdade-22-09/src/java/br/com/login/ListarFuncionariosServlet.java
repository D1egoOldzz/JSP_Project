package br.com.login;

import br.com.conexao.CriarConexao;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ListarFuncionariosServlet")
public class ListarFuncionariosServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Connection con = null;
        try {
           
            con = CriarConexao.getConexao();
            
         
            UsuarioDao usuarioDao = new UsuarioDao(con);
            List<Usuario> listaFuncionarios = usuarioDao.listar();

            
            System.out.println("Número de funcionários encontrados: " + listaFuncionarios.size());
            for (Usuario u : listaFuncionarios) {
                System.out.println("ID: " + u.getId() + ", Email: " + u.getEmail());
            }

            
            request.setAttribute("usuarios", listaFuncionarios);
            
            
            request.getRequestDispatcher("funcionarios.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao listar funcionários.");
        } finally {
           
            try {
                if (con != null && !con.isClosed()) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
