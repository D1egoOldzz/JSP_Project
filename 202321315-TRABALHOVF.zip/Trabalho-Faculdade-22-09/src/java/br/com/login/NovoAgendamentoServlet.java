package br.com.login;

import br.com.conexao.CriarConexao;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class NovoAgendamentoServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    public NovoAgendamentoServlet() {
        super();
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter writer = response.getWriter();
        String nome = request.getParameter("nome-pacient");
        String doctor = request.getParameter("nome-doctor");
        String tipo = request.getParameter("tipo-consulta");
        String datac = request.getParameter("date-consulta");
        String horac = request.getParameter("hora-consulta");
        
        Connection con = CriarConexao.getConexao();
        Agendamento a = new Agendamento();
        a.setNomeCliente(nome);
        a.setNomeDoutor(doctor);
        a.setTipoAgendamento(tipo); 
        a.setDataAgendamento(datac); 
        a.setHorarioAgendamento(horac);
        
        AgendamentoDAO dao = new AgendamentoDAO(con);
        try {
            dao.adicionar(a);
            request.setAttribute("mensagem", "Agendamento criado com sucesso!"); 
        } catch (SQLException ex) {
            Logger.getLogger(NovoAgendamentoServlet.class.getName()).log(Level.SEVERE, null, ex);
            request.setAttribute("mensagem", "Erro ao criar agendamento."); 
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                Logger.getLogger(NovoAgendamentoServlet.class.getName()).log(Level.SEVERE, null, e);
            }
        }
        
        request.getRequestDispatcher("novoagendamento.jsp").forward(request, response);
    }    
}
