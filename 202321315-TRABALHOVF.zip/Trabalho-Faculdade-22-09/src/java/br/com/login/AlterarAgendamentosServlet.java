package br.com.login;

import br.com.conexao.CriarConexao;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AlterarAgendamentosServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    public AlterarAgendamentosServlet() {
        super();
    }
    
   @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    
    PrintWriter writer = response.getWriter();
    String nome = request.getParameter("nome-pacient-e");
    String doctor = request.getParameter("nome-doctor-e");
    String tipo = request.getParameter("tipo-consulta-e");
    String datac = request.getParameter("date-consulta-e");
    String horac = request.getParameter("hora-consulta-e");
    String idStr = request.getParameter("id");
    
    writer.write("Nome: " + nome + ", Doctor: " + doctor + ", Tipo: " + tipo + ", Data: " + datac + ", Hora: " + horac);

    
    Connection con = null;
    try {
        con = CriarConexao.getConexao();
        if (con == null) {
            writer.write("Erro ao conectar ao banco de dados.");
            return;
        }

        Agendamento ae = new Agendamento();
        ae.setNomeCliente(nome);
        ae.setNomeDoutor(doctor);
        ae.setTipoAgendamento(tipo); 
        ae.setDataAgendamento(datac); 
        ae.setHorarioAgendamento(horac);
        ae.setIdAgendamento(Integer.parseInt(idStr)); 
        
        AgendamentoDAO dao = new AgendamentoDAO(con);
        dao.alterar(ae);
        request.setAttribute("mensagem", "Agendamento criado com sucesso!");
    } catch (SQLException ex) {
        Logger.getLogger(AlterarAgendamentosServlet.class.getName()).log(Level.SEVERE, null, ex);
        request.setAttribute("mensagem", "Erro ao criar agendamento.");
    } finally {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                Logger.getLogger(AlterarAgendamentosServlet.class.getName()).log(Level.SEVERE, null, e);
            }
        }
    }
    
    response.sendRedirect("ListarAgendamentosServlet");


}

}

