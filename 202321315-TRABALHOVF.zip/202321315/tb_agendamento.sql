-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30-Set-2024 às 13:54
-- Versão do servidor: 10.4.22-MariaDB
-- versão do PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `logintest`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_agendamento`
--

CREATE TABLE `tb_agendamento` (
  `id_agendamento` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `data_agendamento` varchar(10) DEFAULT NULL,
  `tipo_consulta` varchar(50) DEFAULT NULL,
  `horario` time DEFAULT NULL,
  `doutor` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_agendamento`
--

INSERT INTO `tb_agendamento` (`id_agendamento`, `nome`, `data_agendamento`, `tipo_consulta`, `horario`, `doutor`) VALUES
(2, 'Maria Oliveira', '2024-10-02', 'Consulta de Dieta', '10:00:00', 'Dra. Clara'),
(3, 'Carlos Santos', '2024-10-03', 'Orientação Nutricional', '11:00:00', 'Dra. Clara'),
(4, 'Ana Costa', '2024-10-04', 'Consulta de Acompanhamento', '12:00:00', 'Dra. Clara'),
(5, 'Pedro Almeida', '2024-10-05', 'Reavaliação Nutricional', '13:00:00', 'Dra. Clara'),
(6, 'Laura Mendes', '2024-10-06', 'Consulta de Suplementação', '14:00:00', 'Dra. Clara'),
(7, 'Ricardo Lima', '2024-10-07', 'Orientação de Emagrecimento', '15:00:00', 'Dra. Clara'),
(8, 'Fernanda Pires', '2024-10-08', 'Consulta de Nutrição Esportiva', '16:00:00', 'Dra. Clara'),
(9, 'Sofia Rocha', '2024-10-09', 'Consulta de Acompanhamento', '09:00:00', 'Dra. Clara'),
(10, 'Thiago Ribeiro', '2024-10-10', 'Avaliação Nutricional', '10:00:00', 'Dra. Clara'),
(11, 'Claudia Martins', '2024-10-11', 'Consulta de Dieta', '11:00:00', 'Dra. Clara'),
(12, 'Eduardo Gomes', '2024-10-12', 'Orientação Nutricional', '12:00:00', 'Dra. Clara'),
(13, 'Juliana Alves', '2024-10-13', 'Consulta de Acompanhamento', '13:00:00', 'Dra. Clara'),
(14, 'Lucas Ferreira', '2024-10-14', 'Reavaliação Nutricional', '14:00:00', 'Dra. Clara'),
(15, 'Camila Teixeira', '2024-10-15', 'Consulta de Suplementação', '15:00:00', 'Dra. Clara'),
(16, 'Felipe Cardoso', '2024-10-16', 'Orientação de Emagrecimento', '16:00:00', 'Dra. Clara'),
(17, 'Roberta Dias', '2024-10-17', 'Consulta de Nutrição Esportiva', '09:00:00', 'Dra. Clara'),
(18, 'Rafael Nunes', '2024-10-18', 'Consulta de Acompanhamento', '10:00:00', 'Dra. Clara'),
(19, 'Patrícia Santos', '2024-10-19', 'Avaliação Nutricional', '11:00:00', 'Dra. Clara'),
(20, 'André Souza', '2024-10-20', 'Consulta de Dieta', '12:00:00', 'Dra. Clara'),
(21, 'Lívia Martins', '2024-10-21', 'Orientação Nutricional', '13:00:00', 'Dra. Clara'),
(22, 'Marcos Oliveira', '2024-10-22', 'Reavaliação Nutricional', '14:00:00', 'Dra. Clara'),
(23, 'Tatiane Lopes', '2024-10-23', 'Consulta de Suplementação', '15:00:00', 'Dra. Clara'),
(24, 'Gustavo Lima', '2024-10-24', 'Orientação de Emagrecimento', '16:00:00', 'Dra. Clara'),
(25, 'Bianca Silva', '2024-10-25', 'Consulta de Nutrição Esportiva', '09:00:00', 'Dra. Clara'),
(26, 'Mariana Costa', '2024-10-26', 'Consulta de Acompanhamento', '10:00:00', 'Dra. Clara'),
(27, 'Henrique Santos', '2024-10-27', 'Avaliação Nutricional', '11:00:00', 'Dra. Clara'),
(28, 'Camila Gomes', '2024-10-28', 'Consulta de Dieta', '12:00:00', 'Dra. Clara'),
(29, 'Vinícius Rocha', '2024-10-29', 'Orientação Nutricional', '13:00:00', 'Dra. Clara'),
(30, 'Tatiane Almeida', '2024-10-30', 'Reavaliação Nutricional', '14:00:00', 'Dra. Clara');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tb_agendamento`
--
ALTER TABLE `tb_agendamento`
  ADD PRIMARY KEY (`id_agendamento`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_agendamento`
--
ALTER TABLE `tb_agendamento`
  MODIFY `id_agendamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
