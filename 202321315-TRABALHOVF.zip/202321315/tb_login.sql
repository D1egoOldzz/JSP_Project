-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 28/09/2024 às 09:57
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `logintest`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_login`
--

CREATE TABLE `tb_login` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_login`
--

INSERT INTO `tb_login` (`id`, `nome`, `email`, `senha`) VALUES
(1, 'Amanda Ferreira', 'amanda@hotmail.com', '123'),
(2, 'Bruno Martins', 'bruno@gmail.com', '321'),
(3, 'Carla Souza', 'carla@hotmail.com', '1234'),
(4, 'Diego Almeida', 'diego@gmail.com', '4321'),
(5, 'Eduarda Lima', 'eduarda@hotmail.com', '123'),
(6, 'Felipe Costa', 'felipe@gmail.com', '321'),
(7, 'Gabriela Rocha', 'gabriela@hotmail.com', '1234'),
(8, 'Hugo Santos', 'hugo@gmail.com', '4321'),
(9, 'Isadora Mendes', 'isadora@hotmail.com', '123'),
(10, 'Júlio Nascimento', 'julio@gmail.com', '321'),
(11, 'Karla Oliveira', 'karla@hotmail.com', '1234'),
(12, 'Lucas Ferreira', 'lucas@gmail.com', '4321'),
(13, 'Mariana Gomes', 'mariana@hotmail.com', '123'),
(14, 'Natália Ribeiro', 'natalia@gmail.com', '321'),
(15, 'Otávio Lima', 'otavio@hotmail.com', '1234'),
(16, 'Patrícia Santos', 'patricia@gmail.com', '4321'),
(17, 'Ricardo Alves', 'ricardo@hotmail.com', '123'),
(18, 'Sofia Almeida', 'sofia@gmail.com', '321'),
(19, 'Tiago Martins', 'tiago@hotmail.com', '1234'),
(20, 'Vanessa Costa', 'vanessa@gmail.com', '4321'),
(21, 'Wesley Lima', 'wesley@hotmail.com', '123'),
(22, 'Yasmin Ferreira', 'yasmin@gmail.com', '321'),
(23, 'Zé Carlos', 'zecarlos@hotmail.com', '1234'),
(24, 'André Silva', 'andre@gmail.com', '4321'),
(25, 'Bárbara Almeida', 'barbara@hotmail.com', '123'),
(26, 'César Santos', 'cesar@gmail.com', '321'),
(27, 'Débora Rocha', 'debora@hotmail.com', '1234'),
(28, 'Elias Gomes', 'elias@gmail.com', '4321'),
(29, 'Fernanda Costa', 'fernanda@hotmail.com', '123'),
(30, 'Gustavo Ferreira', 'gustavo@gmail.com', '321'),
(31, 'Helena Santos', 'helena@hotmail.com', '1234'),
(32, 'Igor Nascimento', 'igor@gmail.com', '4321'),
(33, 'Diego', 'diegooldzz@hotmail.com', '1234');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `tb_login`
--
ALTER TABLE `tb_login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_login`
--
ALTER TABLE `tb_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
