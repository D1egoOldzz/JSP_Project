/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AgendamentoDAO {

    private final Connection con;

 public AgendamentoDAO(Connection con) {
        this.con = con;
    }

public List<Agendamento> listar() throws SQLException {
    String sql = "SELECT * FROM tb_agendamento";
    List<Agendamento> lista = new ArrayList<>();
    try (PreparedStatement stmt = con.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            Agendamento adto = new Agendamento();
            adto.setIdAgendamento(rs.getInt("id_agendamento"));
            adto.setHorarioAgendamento(rs.getString("horario"));
            adto.setNomeCliente(rs.getString("nome"));
            adto.setTipoAgendamento(rs.getString("tipo_consulta"));
            adto.setNomeDoutor(rs.getString("doutor"));
            adto.setDataAgendamento(rs.getString("data_agendamento"));
            lista.add(adto);
        }
    }
    return lista;
}

public void adicionar(Agendamento a) throws SQLException {
    String sql = "INSERT INTO tb_agendamento(nome, data_agendamento, tipo_consulta, horario, doutor) VALUES(?, ?, ?, ?, ?)";
    try (PreparedStatement stmt = con.prepareStatement(sql)) {
        stmt.setString(1, a.getNomeCliente());
        stmt.setString(2, a.getDataAgendamento()); 
        stmt.setString(3, a.getTipoAgendamento());
        stmt.setString(4, a.getHorarioAgendamento());
        stmt.setString(5, a.getNomeDoutor()); 
        stmt.executeUpdate();
    }
}



}
