package br.com.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDao {
    private Connection con;

    public UsuarioDao(Connection con) {
        this.con = con;
    }

    public void adicionar(Usuario u) throws SQLException {
        String sql = "INSERT INTO tb_login(nome,email, senha) VALUES(?, ?, ?)";
        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, u.getNome());
            stmt.setString(2, u.getEmail());
            stmt.setString(3, u.getSenha());
            stmt.executeUpdate();
        }
    }

public List<Usuario> listar() throws SQLException {
    String sql = "SELECT * FROM tb_login";
    List<Usuario> lista = new ArrayList<>();
    try (PreparedStatement stmt = con.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            Usuario udto = new Usuario();
            udto.setId(rs.getInt("id"));
            udto.setNome(rs.getString("nome"));
            udto.setEmail(rs.getString("email"));
            lista.add(udto);
        }
    }
    return lista;
}


    public boolean remove(int id) throws SQLException {
        String sql = "DELETE FROM tb_login WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        }
    }
}
