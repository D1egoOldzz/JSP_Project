
const registerDiv = document.getElementById("registerp");
const loginDiv = document.getElementById("loginp");



let registerVisible;
let loginVisible = false;





function alterar(){

    console.log("Foi chamado");
    if (registerVisible == true || registerVisible == null)
    {
        loginDiv.style.animation = "panelrotation 1s normal";
        console.log("foi alterado");
        registerVisible = false;
        loginVisible = true;
        setTimeout(function register(){
            registerDiv.style.display = "none";
            loginDiv.style.display = "block";
        }), 100000;
    }

    else if (registerVisible == false)
    {
        registerDiv.style.animation = "panelrotation 1s normal";
        console.log("foi alterado");
        registerVisible = true;
        loginVisible = false;
        setTimeout(function login(){
            registerDiv.style.display = "block";
            loginDiv.style.display = "none"; 
        }), 100000;
    }   
}