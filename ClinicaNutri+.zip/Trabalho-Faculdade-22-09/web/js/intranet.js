 
     
     document.addEventListener('DOMContentLoaded', () => {   
            const agendamentosButton = document.getElementById("botao-agend");
            const funcionariosButton = document.getElementById("botao-funcio");
            const informacoesButton = document.getElementById("botao-info");
            const novoagendButton = document.getElementById("botao-novoagend");

            const agendamentosSection = document.getElementById("section-agend");
            const novoagendSection = document.getElementById("section-novoagend");
            const funcionariosSection = document.getElementById("section-funcio");
            const informacoesSection = document.getElementById("section-info");

         
            function showSection(sectionToShow) {
                [agendamentosSection, novoagendSection, funcionariosSection, informacoesSection].forEach(section => {
                    section.classList.remove('ativo');
                });
                sectionToShow.classList.add('ativo');
            }

            agendamentosButton.addEventListener('click', () => {
                showSection(agendamentosSection);
                [agendamentosButton, novoagendButton, funcionariosButton, informacoesButton].forEach(btn => {
                    btn.classList.remove('ativo');
                });
                agendamentosButton.classList.add('ativo');
            });

                
            funcionariosButton.addEventListener('click', () => {
                showSection(funcionariosSection);
                [agendamentosButton, novoagendButton, funcionariosButton, informacoesButton].forEach(btn => {
                    btn.classList.remove('ativo');
                });
                funcionariosButton.classList.add('ativo');
            });

            novoagendButton.addEventListener('click', () => {
                showSection(novoagendSection);
                [agendamentosButton, novoagendButton, funcionariosButton, informacoesButton].forEach(btn => {
                    btn.classList.remove('ativo');
                });
               novoagendButton.classList.add('ativo');
            });

            informacoesButton.addEventListener('click', () => {
                showSection(informacoesSection);
                [agendamentosButton, novoagendButton, funcionariosButton, informacoesButton].forEach(btn => {
                    btn.classList.remove('ativo');
                });
                informacoesButton.classList.add('ativo');
            });
        });


 