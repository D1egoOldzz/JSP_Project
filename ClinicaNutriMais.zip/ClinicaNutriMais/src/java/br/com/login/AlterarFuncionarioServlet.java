package br.com.login;

import br.com.conexao.CriarConexao;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AlterarFuncionarioServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    public AlterarFuncionarioServlet() {
        super();
    }
    
   @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    
    PrintWriter writer = response.getWriter();
    String nome = request.getParameter("nome-funcionario-e");
    String email = request.getParameter("email-funcionario-e");
    String senha = request.getParameter("senha-funcionario-e");
    String idf = request.getParameter("id");


    
    Connection con = null;
    try {
        con = CriarConexao.getConexao();
        if (con == null) {
            writer.write("Erro ao conectar ao banco de dados.");
            return;
        }

        Usuario u = new Usuario();
        u.setNome(nome);
        u.setEmail(email);
        u.setSenha(senha); 
        u.setId(Integer.parseInt(idf));
        
        UsuarioDao dao = new UsuarioDao(con);
        dao.alterar(u);
        request.setAttribute("mensagem", "Funcionario alterado com sucesso!");
    } catch (SQLException ex) {
        Logger.getLogger(AlterarFuncionarioServlet.class.getName()).log(Level.SEVERE, null, ex);
        request.setAttribute("mensagem", "Erro ao alterar.");
    } finally {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                Logger.getLogger(AlterarFuncionarioServlet.class.getName()).log(Level.SEVERE, null, e);
            }
        }
    }
    
    response.sendRedirect("ListarFuncionariosServlet");


}

}

