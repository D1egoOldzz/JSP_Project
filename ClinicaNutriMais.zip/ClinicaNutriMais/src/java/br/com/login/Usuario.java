
package br.com.login;

public class Usuario {
    private int id;
    private String email;
    private String senha;
    private String nome;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    void getEmail(String email) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    void setId(String idf) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
 
}
