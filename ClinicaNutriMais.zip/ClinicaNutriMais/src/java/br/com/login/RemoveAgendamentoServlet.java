package br.com.login;

import br.com.conexao.CriarConexao;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RemoveAgendamentoServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public RemoveAgendamentoServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Connection con = null;
        
        try {
      
            con = CriarConexao.getConexao();
            if (con == null) {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Não foi possível estabelecer conexão com o banco de dados.");
                return;
            }

   
            String idStr = request.getParameter("id");
            if (idStr == null || idStr.isEmpty()) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID do agendamento não fornecido.");
                return;
            }

            int id;
            try {
                id = Integer.parseInt(idStr);
            } catch (NumberFormatException e) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID inválido.");
                return;
            }

    
            AgendamentoDAO agendamentoDao = new AgendamentoDAO(con);
            boolean removed = agendamentoDao.remove(id);

          
            String message;
            if (removed) {
                message = "Agendamento removido com sucesso.";
                request.setAttribute("message", message); 
                 response.sendRedirect("ListarAgendamentosServlet");
            } else {
                message = "Agendamento não encontrado.";
                request.setAttribute("message", message); 
                response.sendRedirect("ListarAgendamentosServlet");
            }
        } catch (SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao remover funcionário.");
        } finally {
            try {
                if (con != null && !con.isClosed()) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace(); 
            }
        }
    }
}
