
package br.com.conexao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class CriarConexao {
    public static Connection getConexao(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.print("conectouuu");
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/logintest", "root", "");
        } catch (ClassNotFoundException | SQLException e) {
        }
        return null;
    }
    
}
    
  
       

